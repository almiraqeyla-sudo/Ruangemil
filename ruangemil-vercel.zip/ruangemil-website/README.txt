RUANGEMIL — WEBSITE MENU RISOL

Website ini berisi:
- Logo Ruangemil yang diberikan
- Menu dan harga risol
- Pemilih jumlah, keranjang, dan total otomatis
- Nama pemesan wajib diisi
- Copy Order dan Order via WhatsApp
- Tombol WhatsApp diarahkan ke 088222055901 (tautan menggunakan format internasional 6288222055901)

Cara deploy ke Vercel:
1. Unggah index.html dan folder assets ke repository GitHub yang sama.
2. Buka https://vercel.com/ dan login dengan GitHub.
3. Pilih Add New → Project, lalu import repository.
4. Pilih preset Other jika diminta, lalu Deploy.
5. Bagikan URL yang diberikan Vercel.

Jangan pisahkan folder assets dari index.html, karena gambar logo dipanggil dari folder tersebut.
